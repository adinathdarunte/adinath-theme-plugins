__( 'CSS code', 'elementor-pro' );
__( 'Custom CSS', 'elementor-pro' );